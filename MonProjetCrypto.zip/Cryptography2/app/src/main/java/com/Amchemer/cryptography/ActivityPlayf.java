package com.Amchemer.cryptography;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.security.Key;

public class ActivityPlayf extends AppCompatActivity {
    TextView Result;
    EditText CryptV , DecryptV , KeyV;
    Button EncV , DecV , RetV  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playf);

        Result = findViewById(R.id.result);
        CryptV = findViewById(R.id.textCV);
        DecryptV = findViewById(R.id.textDV);
        KeyV = findViewById(R.id.keyV);
        EncV = findViewById(R.id.crypV);
        DecV = findViewById(R.id.decrypV);
        RetV = findViewById(R.id.retourV);


        EncV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String R = PlayfairCipher.EncryptionPlay(CryptV.getText().toString(), KeyV.getText().toString());
                DecryptV.setText(R);

            }
        });

        DecV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String R = PlayfairCipher.DecryptionPlay(DecryptV.getText().toString(), KeyV.getText().toString());
                CryptV.setText(R);

            }
        });

        RetV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(ActivityPlayf.this,Activity2.class);
                startActivity(intent);
            }
        });
    };
}

