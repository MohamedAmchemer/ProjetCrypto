package com.Amchemer.cryptography;
import java.util.Scanner;


public class AtbashCipher {

    private static Scanner in;

    static String decryptionAtb(String message  ) {
        String alpa = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String reverseAlpa = "";
        // reversing alphabets
        for (int i = alpa.length()-1; i > -1; i--) {
            reverseAlpa += alpa.charAt(i);
        }

        message = message.toUpperCase();

        String dencryText = "";
        for (int i = 0; i < message.length(); i++) {
            if(message.charAt(i) == (char)32){
                dencryText += " ";
            } else {
                int count = 0;
                for (int j = 0; j < reverseAlpa.length(); j++) {
                    if (message.charAt(i) == reverseAlpa.charAt(j)){
                        dencryText += alpa.charAt(j);
                        break;
                    }
                }
            }
        }

        return dencryText;
    }
    static String encryptionAtb(String message) {
        String alpa = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String reverseAlpa = "";
        // reversing alphabets
        for (int i = alpa.length()-1; i > -1; i--) {
            reverseAlpa += alpa.charAt(i);
        }

        message = message.toUpperCase();

        String encryText = "";
        for (int i = 0; i < message.length(); i++) {
            if(message.charAt(i) == (char)32){
                encryText += " ";
            } else {
                int count = 0;
                for (int j = 0; j < alpa.length(); j++) {
                    if (message.charAt(i) == alpa.charAt(j)){
                        encryText += reverseAlpa.charAt(j);
                        break;
                    }
                }
            }
        }
        return  encryText;
    }

}