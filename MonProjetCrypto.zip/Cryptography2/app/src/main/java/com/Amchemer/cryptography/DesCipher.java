package com.Amchemer.cryptography;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.util.ArrayList;

public class DesCipher {
    public SecretKey getSecretKey(String algorithm, int bits){
        KeyGenerator keyGenerator = null;
        try{
            keyGenerator = KeyGenerator.getInstance(algorithm);
            keyGenerator.init(bits);
        }catch(Exception ex){
            ex.printStackTrace();
            return null;
        }
        return keyGenerator.generateKey();
    }
    public static byte[] CryptDes( String algorithm , byte[] messageToEncrypt , SecretKey secretKey){
        Cipher cipher = null;
        byte[] result;
        try{
            cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            result = cipher.doFinal(messageToEncrypt);
        }catch(Exception ex){
            ex.printStackTrace();
            return null;
        }
        return result;
    }
    public static byte[] DecryptDes(String algorithm, SecretKey secretKey, byte[] messageEncrypted){
        Cipher cipher = null;
        byte[] result;
        try{
            cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.DECRYPT_MODE,secretKey);
            result = cipher.doFinal(messageEncrypted);
        }catch(Exception ex){
            ex.printStackTrace();
            return null;
        }
        return result;
    }

}