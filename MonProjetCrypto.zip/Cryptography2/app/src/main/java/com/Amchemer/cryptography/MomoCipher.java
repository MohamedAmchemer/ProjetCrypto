package com.Amchemer.cryptography;
import java.util.Scanner;


public class MomoCipher {

    private static Scanner in;

    public static String cipherDecryptionM(String msg , String key) {
        String hexToDeci = "";
        for (int i = 0; i < msg.length()-1; i+=2) {
            // splitting hex into a pair of two
            String output = msg.substring(i, (i+2));
            int decimal = Integer.parseInt(output, 16);
            hexToDeci += (char)decimal;
        }
        // decryption
        String decrypText = "";
        int keyItr = 0;
        for (int i = 0; i < hexToDeci.length(); i++) {
            // XOR Operation
            int temp = hexToDeci.charAt(i) ^ key.charAt(keyItr);

            decrypText += (char)temp;
            keyItr++;
            if(keyItr >= key.length()){

                keyItr = 0;
            }
        }
        return decrypText;
    }
    public static String cipherEncryptionM(String msg , String key) {
        String encrypHexa = "";
        int keyItr = 0;
        for (int i = 0; i < msg.length(); i++) {
            // XOR Operation
            int temp = msg.charAt(i) ^ key.charAt(keyItr);

            encrypHexa += String.format("%02x", (byte)temp);
            keyItr++;
            if(keyItr >= key.length()){

                keyItr = 0;
            }
        }
        return encrypHexa;
    }
}