package com.Amchemer.cryptography;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ActivityAtb extends AppCompatActivity {
    TextView Result;
    EditText CryptV , DecryptV , KeyV;
    Button EncV , DecV , RetV  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atb);

        Result = findViewById(R.id.result);
        CryptV = findViewById(R.id.textCV);
        DecryptV = findViewById(R.id.textDV);
        KeyV = findViewById(R.id.keyV);
        EncV = findViewById(R.id.crypV);
        DecV = findViewById(R.id.decrypV);
        RetV = findViewById(R.id.retourV);


        EncV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String R = AtbashCipher.encryptionAtb(CryptV.getText().toString() );
                DecryptV.setText(R);



            }
        });

        DecV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String R = AtbashCipher.decryptionAtb(DecryptV.getText().toString());
                CryptV.setText(R);

            }
        });

    RetV.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(ActivityAtb.this,Activity2.class);
            startActivity(intent);
        }
    });


        };
    }




