package com.Amchemer.cryptography;

public class CesarCipher {

        public static String encryptC(String texte , int chave) {
            StringBuilder textchif = new StringBuilder();
            int TexteL = texte.length();

            for (int c = 0; c < TexteL; c++) {
                int lettreASCII = (texte.charAt(c)) + (chave);

                while (lettreASCII > 126) {
                    lettreASCII -= 94;
                }

                textchif.append((char) lettreASCII);
            }

            return textchif.toString();
        }

        public static String decryptC(String textChiffre , int chave) {
            StringBuilder texte = new StringBuilder();
            int TexteL = textChiffre.length();

            for (int c = 0; c < TexteL; c++) {
                int lettreASCII = (textChiffre.charAt(c)) - (chave);

                while (lettreASCII < 32) {
                    lettreASCII += 94;
                }

                texte.append((char) lettreASCII);
            }

            return texte.toString();
        }
    }