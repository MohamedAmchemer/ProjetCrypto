package com.Amchemer.cryptography;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView Result;
    EditText Crypt , Decrypt , Key;
    Button Enc , Dec , Ret , Vi ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Result = findViewById(R.id.result);
        Crypt = findViewById(R.id.textC);
        Decrypt = findViewById(R.id.textD);
        Key = findViewById(R.id.key);
        Enc = findViewById(R.id.cryp);
        Dec = findViewById(R.id.decryp);
        Ret = findViewById(R.id.retour);
        Vi = findViewById(R.id.vig);

        Enc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String R = CesarCipher.encryptC(Crypt.getText().toString(), Integer.valueOf(Key.getText().toString()) );
                Decrypt.setText(R);


            }
        });

        Dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String R = CesarCipher.decryptC(Decrypt.getText().toString(), Integer.valueOf(Key.getText().toString()) );
                Crypt.setText(R);
                
            }
        });

        Ret = (Button)findViewById(R.id.retour);
        Ret.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 Intent intent =  new Intent(MainActivity.this,Activity2.class);
                 startActivity(intent);
            }
        });
        };
    }

