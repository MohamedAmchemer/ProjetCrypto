package com.Amchemer.cryptography;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Activity2 extends AppCompatActivity {
        Button Ce , Hi , Pl , At , Vi , Ho , De , Mo, RS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        Ce = findViewById(R.id.cesar);
        Hi = findViewById(R.id.hill);
        Pl = findViewById(R.id.playf);
        At= findViewById(R.id.atb);
        Vi = findViewById(R.id.vig);
        Ho = findViewById(R.id.homo);
        De = findViewById(R.id.des);
        Mo= findViewById(R.id.momo);
        RS = findViewById(R.id.rsa);


        Ce = (Button)findViewById(R.id.cesar);
        Ce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,MainActivity.class);
                startActivity(intent);
            }
        });


        Vi = (Button)findViewById(R.id.vig);
        Vi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,ActivityVig.class);
                startActivity(intent);

            }
        });

        Hi = (Button)findViewById(R.id.hill);
        Hi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,ActivityHill.class);
                startActivity(intent);
            }
        });

        At= (Button)findViewById(R.id.atb);
        At.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,ActivityAtb.class);
                startActivity(intent);
            }
        });

        Mo = (Button)findViewById(R.id.momo);
        Mo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,ActivityMomo.class);
                startActivity(intent);
            }
        });


        Pl = (Button)findViewById(R.id.playf);
        Pl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,ActivityPlayf.class);
                startActivity(intent);
            }
        });

        Ho = (Button)findViewById(R.id.homo);
        Ho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,Activity_Polybe.class);
                startActivity(intent);
            }
        });

        Ho = (Button)findViewById(R.id.homo);
        Ho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,Activity_Polybe.class);
                startActivity(intent);
            }
        });

        RS = (Button)findViewById(R.id.rsa);
        RS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Activity2.this,ActivityRsa.class);
                startActivity(intent);
            }
        });


    }
}
