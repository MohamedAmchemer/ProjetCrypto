package com.Amchemer.cryptography;
import java.util.Scanner;


public class PolybeCipher {




    public static int[] Code_Polybe(String mot) {
        // INITIALISATION DU TABLEAU CarreDePolybe
        char[][] Tc = new char[][] {
                {'A','B','C','D','E'},
                {'F','G','H','I','J'},
                {'K','L','M','N','O'},
                {'P','Q','R','S','T'},
                {'U','V','X','Y','Z'}
        };
        // INITIALISATION TABLEAU c : mot codé avec carré de Polybe

        int c [] = new int [ mot.length()*2];
        char lettre;
        int pos = 0;
        for (int k=0; k < mot.length(); k++ ) {
            lettre = mot.charAt(k);
            // TEST V ou W
            if ( lettre == 'W') lettre = 'V';
            // PARCOURT du carré de Polybe
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    // INITIALISATION c à la valeur du carré de polybe
                    if (lettre == Tc[i][j]) {
                        c[pos++] = i;
                        c[pos++] = j;
                    }
                }
            }
        }
        return c;
    }



    public static String Decode_Polybe(int[] mot_crypte) {
        // INITIALISATION DU TABLEAU CarreDePolybe
        char[][] Td = new char[][] {
                {'A','B','C','D','E'},
                {'F','G','H','I','J'},
                {'K','L','M','N','O'},
                {'P','Q','R','S','T'},
                {'U','V','X','Y','Z'}
        };

        String mot ="";
        int i=9,j=9;

        for (int k = 0; k < mot_crypte.length-1; k = k+2 ) {
            i = mot_crypte[k];
            j = mot_crypte[k+1];
            if ( Td[i][j] == 'V') {
                mot += "(V/W)";
            } else {
                mot += Td[i][j];
            }
        }
        return mot;
    }


}
